$( function() {
    $( "#resizable" ).resizable();
    $( "#resizable" ).draggable();
  } );


  $( function() {
    $( "#draggable" ).draggable();
  } );